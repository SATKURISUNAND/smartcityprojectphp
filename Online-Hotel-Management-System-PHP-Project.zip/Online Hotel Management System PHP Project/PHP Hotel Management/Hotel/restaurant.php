<html>
<head>
	<title>restaurant</title>
	<link rel="stylesheet" type="text/css" href="link.html">
</head>
<body bgcolor="#fff2e5">
<?php
	include "index.php";
?>
<br><br>
<center><font color=choco size=4><b><i><u>RESTAURANT</u></i></b></font></center>
<br><br>
<center><font color="#7c0000" size=4>Restaurant:Sessions</font></center>
<table>
<tr>
	<td><a href=r1.php target=_blank><img src="image/dining3.jpg" width=125 height=150></a></td>
	<td>Internationally styled restaurants in Rajkot,provide you a thoroughly restful serving you the 
	Sessions of the word with some of the most inpressive food. Sessions introduces a new concept in
	duisine to spice up your food life with a restaurant for family,lunch and entertainment.</td>
	<td><a href=r2.php target=_blank><img src="image/dining2.jpg" width=125 height=150></a></td>
</tr>
<tr>
	<td><font color="#7c0000">Entry</font></td>
	<td></td>
	<td><font color="#7c0000">Palm</font></td>
</tr>
</table>
<br><br>
<table width="900px">
<tr>
	<td rowspan=3><a href=r3.php target=_blank><img src="image/dining1.jpg" width='125' height='150'></a></td>
	<td><font color="#7c0000">TIMMING:</td>
	<td></td>
	<td rowspan=3><a href=r4.php target=_blank><img src="image/delicacy.jpg" width='125' height='150'></a></td>
</tr>
<tr>
	<td>Lunch :12.00 to 15.30 hours</td>
</tr>
<tr>
	<td>Dinner :19.00 to 23.30 hours</td>
</tr>
<tr>
	<td><font color="#7c0000">Sitting style</font></td>
	<td></td>
	<td></td>
	<td><font color="#7c0000">Cuisine</font></td>
</tr>
</table>
<p><br>
  <br>
    <font color="#7c0000" size=5>Cuisine   :</font>
  <br>
  <br>
    <font color=darkpink size=4>Indian/Chiness/Mexican/Continetal</font></p>
<marquee behavior=alternate bgcolor="#7e0000"><b><i><a href=contectus.php><font color="white">Devloped By :- Finava Vipul & Metaliya Nikunj </a></i></b></font></marquee>
</body>
</html>