<?php

		$server="localhost";
		$unm="root";
		$pwd="";
		$db="hotel";

		$con=mysql_connect($server,$unm,$pwd);
		mysql_select_db($db,$con);
?>