<html>
<head>
	<title>Location page</title>
	<link rel="stylesheet" type="text/css" href="link.php"></head>
<body bgcolor="#fff2e5">
<?php 
	include "index.php";
?>
<br>
<table border=0>
	<tr>
		<td>&nbsp;</td>
		<td align=center><font color=choco size=4><b><i><u>LOCATION</u></i></b></td></font>
	</tr>
	<tr>
		<td><a href=11.php target=_blank><img src="image/hoverview.jpg" width=150 height=150></a></td>
		<td>Hotel<strong><em><font color="violet">PARAS</font></em></strong>is strategically located colse to the business hub of Amreli
		and in close vicinity of the Railway station and central Bus station.
		It provides an easy access to the industrial zones of Amreli.
		of you are travelling by car.</td>
		<td><a href=12.php target=_blank><img src="image/regal4.jpg" width=150 height=150></a></td>
	</tr>
	<tr>
		<td><font color="#7c0000"></font>Overview</td>
		<td></td>
		<td><font color="#7c0000">Hall</font></td>
	</tr>
</table>
<br><br>
<table width=100%>
	<tr>
		<td rowspan=4><a href=13.php target=_blank><img src="image/regal3.jpg" width=150 height=150></a></td>
		<th>LOCATION</th>
		<th>DISTANCE</th>
		<td rowspan=4><a href=14.php target=_blank><img src="image/meeting3.jpg" width=150 height=150 align=right></a></td>
	</tr>
	<tr>
		<td>&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td>Railway-Station</td>
		<td>1 Km</td>
	</tr>
	<tr>
		<td>Bus Station</td>
		<td>0 Km</td>
	</tr>
	<tr>
		<td><font color="#7c0000">Sitting</font></td>
		<td></td>
		<td></td>
		<td align=middle><font color="#7c0000"> regal </font></td>
	</tr>
</table>
<marquee behavior=alternate bgcolor="#7e0000"><b><i><a href=contectus.php><font color="white">Devloped By :- Finava Vipul & Metaliya Nikunj </a></i></b></font></marquee>
</body>
</html>
</html>