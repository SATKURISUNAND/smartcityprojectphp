<html>
<head>
	<title>deluxe</title>
</head>
<body>
<center><font color=purple size=6><a href=deluxe1.php>Deluxe</a></font></center>
<img src="image/exe1.jpg" height=400 width=750>
<font color=purple size=3.
<pre>
	luxuriously furnished room having a sofa cum bed for an extra adult or child with wall to wall
	carpet.this rooms are attached with private window over looking the swimming pool.</font>
</pre>
<a href=accommodation.php>home</a>
</body>
</html>