<html>
<head>
	<title>accommodation page</title>
	<link rel="stylesheet" type="text/css" href="link.php">
</head>
<body bgcolor="#fff2e5">
<?php
	include "index.php";
?>
<br><br>
<center><font color=choco size=4><b><i><u>ACCOMODATION</u></i></b></font></center>
<table width=100%>
	<tr>
		<td><a href=suite2.php target=_blank><img src="image/p01.jpg" width=150 height=150></a></td>
		<td><font size=3 color=red>ROOMS & SUITES:</font></td>
		<td><a href=tariff.php>Tariff</a></td>
		<td align=right><a href=superdeluxe2.php target=_blank><img src="image/hsuites.jpg" width=150 height=150></a></td>
	</tr>
	<tr>
		<td><font color="#7c0000">Suite</font></td>
		<td></td>
		<td></td>
		<td align=middle><font color="#7c0000">Superdeluxe</font></td>
	</tr>
</table>
<br><br>
<table border=0 width=100%>
	<tr>
		<td rowspan=6><a href=deluxe2.php target=_blank><img src="image/exe1.jpg" width=150 height=150></a></td>
		<th>Room</th>
		<th>Total</th>
		<td rowspan=6 align=right><a href=standard2.php targer=_blank><img src="image/piccolino_hotel_10.jpg" width=150 height=150></a></td>
	</tr>
	<tr>
		<td><a href=suite1.php>Suite</a></td>
		<td>6</td>
	</tr>
	<tr>
		<td><a href=superdeluxe1.php>Superdeluxe</a></td>
		<td>10</td>
	</tr>
	<tr>
		<td><a href=deluxe1.php>Deluxe</a></td>
		<td>30</td>
	</tr>
	<tr>
		<td><a href=standard1.php>Standard</a></td>
		<td>15</td>
	</tr>
	<tr>
		<td>Total</td>
		<td>61</td>
	</tr>
	<tr>
		<td><font color="#7c0000">Deluxe</font></td>
		<td></td>
		<td>&nbsp;</td>
		<td align=middle><font color="#7c0000">Standard</font></td>
	</tr>
</table>
<marquee behavior=alternate bgcolor="#7e0000"><b><i><a href=contectus.php><font color="white">Devloped By :- Finava Vipul & Metaliya Nikunj </a></i></b></font></marquee>
</body>
</html>