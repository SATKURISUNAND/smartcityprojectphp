<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body bgcolor="#fff2e5" alink="#0000FF" vlink="#0000FF">

<?php
	include "index.php";
?>

<p><em><font color="#FF9900"><strong><u><font size="7"><font face="Georgia, Times New Roman, Times, serif">Contact Us</font></font></u></strong> </font></em>></p>

<p>

<p><em><font color="#FFCC00"><strong><font color="#FF0066" size="5" face="Georgia, Times New Roman, Times, serif">Connect Publishers Pvt. Ltd .</font></strong></font></em>
<p><em><strong><font color="#FF0066" size="5" face="Georgia, Times New Roman, Times, serif"> </font></strong></em><font color="#FF0000"></font><font color="#FF0000"></font><font color="#FF0000"></font><font color="#FF0000"></font>
<font color="#FF0000"><TR></tr>
</font><font color="#FF0000"><em><strong><font color="#FF9933" size="5" face="Georgia, Times New Roman, Times, serif">Finava Vipul</font></strong></em><strong><font color="#C0C0C0"></br>
</font></strong></font><font color="#0000"><strong><em><font size="4" face="Georgia, Times New Roman, Times, serif">Uma Vansi</font></em>  <br>
<em><font size="4" face="Georgia, Times New Roman, Times, serif">Vdiya Road,</font></em></br> 
<em><font size="4" face="Georgia, Times New Roman, Times, serif">Anida-365450.</font></em> <br>
<em><font size="4" face="Georgia, Times New Roman, Times, serif">E-mail : finava.vipul@gmail.com</font></em></br> 
<em><font size="4" face="Georgia, Times New Roman, Times, serif">Mobile :  9825817442</font></em> <br>
 </strong></font>  
</p>

<p><font color="#FF0066"><strong><font size="5" face="Georgia, Times New Roman, Times, serif"><em>Connect Publishers Pvt. Ltd.</em></font></strong></font>
<font color="#FF0000"><br>
<TR></tr>
</font>
<p><font color="#FF0000"><strong><em><font color="#FF9933" size="5" face="Georgia, Times New Roman, Times, serif">Metaliya Nikunj</font></em><font color="#C0C0C0"></br> 
  </font></strong></font> <font color="#0000"><strong>
    <em><font size="4" face="Georgia, Times New Roman, Times, serif">Near Cinema </font></em><br>
    <em><font size="4" face="Georgia, Times New Roman, Times, serif">Chavand Road</font></em></br> 
    <em><font size="4" face="Georgia, Times New Roman, Times, serif">Lathi-365430</font></em> <br>
    <em><font size="4" face="Georgia, Times New Roman, Times, serif">E-mail : metaliya_nikunj@yahoo.com</font></em></br> 
    <em><font size="4" face="Georgia, Times New Roman, Times, serif">Mobile : 9601626442</font></em><br>
     </strong></font>
</p>
</p>
<p align="center">


</body>
</html>
